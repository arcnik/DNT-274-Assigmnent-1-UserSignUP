﻿using Microsoft.AspNetCore.Mvc;
using MVC_SignUp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace MVC_SignUp.Controllers
{
    public class AccountController : Controller
    {
        [HttpGet]
        public IActionResult Signup()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Signup(User_signup user)
        {
            if (!ModelState.IsValid)
            {

            }
            return View();
        }
        public IActionResult Message()
        {

            return View();
        }
    }
}
