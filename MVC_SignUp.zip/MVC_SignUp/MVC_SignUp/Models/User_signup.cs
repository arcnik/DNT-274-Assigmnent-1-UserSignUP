﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MVC_SignUp.Models
{
    public class User_signup
    {
        [Required(ErrorMessage ="Please Enter Name")]
        public string Name { get; set; }
     
        [Required(ErrorMessage = "Please Enter Password")]
        public string password { get; set; }

        [Required(ErrorMessage = "Please Enter Confrim Password")]
        [Compare("password", ErrorMessage = "Confirm Password does not match")]
        public string confirmpassword { get; set; }
     
        public string Gender { get; set; }

        [Required(ErrorMessage = "Please Enter Contact No")]
        [RegularExpression("^[6,7,8,9]\\{9}$", ErrorMessage = "Please Enter valid Contact No.")]
        public string contact { get; set; }
        public string country { get; set; }
        public string city { get; set; }

        [Required(ErrorMessage = "Please Accept Terms.")]
        public bool Terms { get; set; }
    }
    public enum country
    {
        India,
        UK,
        USA
    }
}
